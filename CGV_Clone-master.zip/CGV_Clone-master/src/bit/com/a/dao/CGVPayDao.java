package bit.com.a.dao;

import bit.com.a.model.CGVPayDto;

public interface CGVPayDao {

	public boolean payTicket(CGVPayDto dto);
}
