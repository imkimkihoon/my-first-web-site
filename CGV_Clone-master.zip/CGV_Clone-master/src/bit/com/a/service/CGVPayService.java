package bit.com.a.service;

import bit.com.a.model.CGVPayDto;

public interface CGVPayService {
	public boolean payTicket(CGVPayDto dto);
}
